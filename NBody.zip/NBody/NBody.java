/*************************************************************************
*  Author: Anna Denisova
*
*  Compilation: javac NBody.java
*  Execution: java NBody T t 
*
*  Пояснения относительно использования других переменных внутри кода
*
*************************************************************************/
public class NBody {
	public static void main(String args[]) {
		double T = Double.parseDouble(args[0]); // Максимальное время работы
		double t = Double.parseDouble(args[1]); // Смещение для ускорения
		int N = (int)StdIn.readDouble(); // Ввод количества тел в системе
		double R = Double.parseDouble(StdIn.readString()); // Радиус
		double[] rx = new double[N]; // Ассимптоты
		double[] ry = new double[N]; // Ординаты
		double[] vx = new double[N]; // Скорость по х
		double[] vy = new double[N]; // Скорость по у
		double[] mass = new double[N]; // Масса
		String[] graf = new String[N]; // Название файла для анимации
		double G = 6.67 * (Math.pow(10,(-11))); // Гравитационная постоянная
		double[] fx = new double[N]; // Сила по оси х
		double[] fy = new double[N]; // Сила по оси у 
		double[] ax = new double[N]; // Вспомогательный массив для расчета ускорения по х
		double[] ay = new double[N]; // Аналогично для оси у
		double t1 = 0.0; // Счетчик времени
	
		for (int i = 0; i < N; i++) {
			rx[i] = Double.parseDouble(StdIn.readString());
			ry[i] = Double.parseDouble(StdIn.readString());
			vx[i] = Double.parseDouble(StdIn.readString());
			vy[i] = Double.parseDouble(StdIn.readString());
			mass[i] = Double.parseDouble(StdIn.readString());
			graf[i] = StdIn.readString();
			fx[i] = 0.0;
			fy[i] = 0.0;
		}
		// Ввод данных
		StdDraw.setXscale(-R,+R);
		StdDraw.setYscale(-R,+R);
		StdDraw.enableDoubleBuffering();
		StdDraw.picture(0,0,"starfield.jpg");
		// Рисуем фон
		while (t1<T) {
			for (int j = 0; j < N; j++) {
				for (int i = 0; i < N; i++) {
					if (i != j) {
						double r = Math.sqrt((Math.pow((rx[i] - rx[j]),2))+(Math.pow((ry[i] - ry[j]),2)));
						double sinus = ((ry[i]-ry[j])/r);
						double cosinus = ((rx[i]-rx[j])/r);
						fx[j] = fx[j]+(G*mass[j]*mass[i])*cosinus/(Math.pow(r,2));
						fy[j] = fy[j]+(G*mass[i]*mass[j])*sinus/(Math.pow(r,2));
					}
				}
			}
			// Расчет силы
			for (int i = 0; i < N; i++) {
				ax[i] = fx[i]/mass[i];
				ay[i] = fy[i]/mass[i];
			}
			// Рассчет ускорения
			for (int i = 0; i < N; i++) {
				fx[i] = 0.0;
				fy[i] = 0.0;
			}
			// Обнуление силы для вычисления следующей точки
			StdDraw.picture(0,0,"starfield.jpg");
			for (int i = 0; i < N; i++) {
				vx[i] = vx[i] + ax[i]*t;
				vy[i] = vy[i] + ay[i]*t;
				rx[i] = rx[i]+ vx[i]*t;
				ry[i] = ry[i]+ vy[i]*t;
				StdDraw.picture(rx[i],ry[i],graf[i]);
			}
			// Вычисление новой скорости и новых координат
			StdDraw.show();
			t1 = t1 + t;
			// Учет счетчика времени
		}
		StdAudio.play("2001.wav"); // Мелодия для настроения
		for (int i = 0; i < N; i++) {
			System.out.print(rx[i] + " ");
			System.out.print(ry[i] + " ");
			System.out.print(vx[i] + " ");
			System.out.print(vy[i] + " ");
			System.out.print(mass[i] + " ");
			System.out.print(graf[i] + " ");
			System.out.println();
		}
		// Вывод состояния вселенной
	}
}	